package com.example.appbioskop;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class FragmentA extends Fragment {
    private EditText editTextJudul, editTextGenre, editTextTahun;
    private Button buttonTambahFilm;

    public FragmentA() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_a, container, false);

        // Inisialisasi komponen form input
        editTextJudul = view.findViewById(R.id.editTextJudul);
        editTextGenre = view.findViewById(R.id.editTextGenre);
        editTextTahun = view.findViewById(R.id.editTextTahun);
        buttonTambahFilm = view.findViewById(R.id.buttonTambahFilm);

        buttonTambahFilm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ambil data input dari form
                String judul = editTextJudul.getText().toString();
                String genre = editTextGenre.getText().toString();
                String tahun = editTextTahun.getText().toString();

                // Buat bundle untuk mengirim data ke FragmentDua
                FragmentB fragmentB = new FragmentB();
                Bundle bundle = new Bundle();
                bundle.putString("judulFilm", judul);
                bundle.putString("genreFilm", genre);
                bundle.putString("tahunFilm", tahun);
                fragmentB.setArguments(bundle);

                // Ganti fragment
                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, fragmentB);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        return view;
    }
}