package com.example.apptiketbioskop;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btn;
    EditText nameEdit, filmEdit, studioEdit, hargaEdit;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.submitBtn);
        nameEdit = findViewById(R.id.nameEdit);
        filmEdit = findViewById(R.id.filmEdit);
        studioEdit = findViewById(R.id.studioEdit);
        hargaEdit = findViewById(R.id.hargaEdit);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendDatatoFragment();
            }
        });
    }

    private void sendDatatoFragment(){
        String name,film, studio,price = "";

        name = nameEdit.getText().toString();
        film = filmEdit.getText().toString();
        studio = studioEdit.getText().toString();
        price = hargaEdit.getText().toString();

        Fragment frag = new FragmentA();

        Bundle bundle = new Bundle();

        bundle.putString("username", name);
        bundle.putString("userfilm", film);
        bundle.putString("userstudio", studio);
        bundle.putString("userprice", price);

        frag.setArguments(bundle);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.container, frag).commit();
    }
}