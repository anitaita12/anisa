package com.example.apptiketbioskop;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class FragmentA extends Fragment {
    TextView details;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_a, container, false);

        details = view.findViewById(R.id.details);

        Bundle bundle = this.getArguments();

        details.setText("Name :" + bundle.getString("username")
                +"\nFilm : "+bundle.getString("userfilm")
                +"\nStudio : "+bundle.getString("userstudio")
                +"\nPrice : "+bundle.getString("userprice"));

        return view;
    }
}